---
name: benchmark-mercado
description: Orquestra benchmark de mercado multiagente por nicho ou lista de perfis usando Google, hashtags, Instagram, Meta Ads Library, paginas publicas, Reels e criativos. Use quando o usuario pedir pesquisa de concorrencia, espionar nicho, analisar arrobas, anuncios persistentes, Reels engajados, promessas, ICP, niveis de consciencia, dossie comercial, Wow Document ou pacote final de inteligencia. O escopo termina na coleta, analise, transcricao e geracao dos documentos; nao criar nem publicar sites.
---

# Benchmark de Mercado e Wow Document

## Escopo e objetivo

Gerar pesquisas auditaveis de um nicho ou de perfis especificos usando Google, Instagram, Meta Ads Library, links da bio e paginas de destino. A pesquisa pode usar Chrome com uma sessao autorizada e perfil dedicado para descoberta visual; Apify permanece como fallback para coleta estruturada. Nunca inventar acesso, transcricao ou conclusao; registrar claramente o que abriu, o que falhou e o que precisa ser liberado.

Entregar, no minimo: manifesto da pesquisa, dados brutos preservados, dossies por player, midias elegiveis com metadata, transcricoes quando possivel, Wow Document consolidado e um indice final de fontes. Nao criar landing page, banco de leads, tutorial de download, deploy, dominio ou qualquer outra etapa de site nesta skill.

## Orquestracao multiagente

Quando houver mais de 3 perfis ou o usuario pedir pesquisa aprofundada, usar agentes especializados em paralelo. Ler `references/multi-agent-workflow.md` antes de delegar.

O agente principal permanece como orquestrador: define criterios, cria o manifest, distribui tarefas, revisa evidencias, resolve conflitos e gera os documentos finais. Cada agente escreve apenas em seu diretorio de trabalho e devolve caminhos, contagens, fontes abertas, falhas e custos.

Dividir por funcao, nunca duplicar o mesmo escopo:

- Descoberta: Google, hashtags, candidatos, perfis e URLs publicas.
- Instagram: perfil, Reels, metricas e janela de 90 dias.
- Meta Ads: Biblioteca de Anuncios, CTA, copias, datas e agrupamento de criativos.
- Oferta/ICP: bio, paginas publicas, promessa, mecanismo, prova, oferta e linguagem.
- QA/editorial: deduplicacao, filtros, transcricoes, separacao fato/inferencia e lacunas.

Para poucos perfis, executar as mesmas funcoes localmente e manter a estrutura de saida; nao criar agentes apenas por formalidade.

## Fluxo por nicho ou lista de perfis

Para uma pesquisa iniciada por nicho, ler `references/niche-workflow.md` e `references/awareness-framework.md`:

1. Preparar o manifesto, criterios, janela, nicho, ICP e lista de perfis.
2. Buscar nicho no Google e Instagram em paralelo; consolidar perfis publicos, marcas, dominios e paginas.
3. Pesquisar Meta Ads Library por nome, arroba, pagina, marca e dominio.
4. Coletar Reels dos ultimos 90 dias e selecionar os que atingirem os filtros.
5. Agrupar anuncios por criativo/variante e selecionar anuncios persistentes.
6. Baixar somente midia acessivel pela sessao autorizada ou URLs publicas retornadas pelas fontes.
7. Transcrever midia localmente quando houver arquivo ou URL publica.
8. Montar dossies por player, depois consolidar o Wow Document por nicho.
9. Rodar QA final: fontes, metricas, filtros, links, transcricoes, vieses, lacunas e conteudo pessoal excluido.

Para iniciar a estrutura de uma pesquisa por nicho:

```bash
node .agents/skills/benchmark-mercado/scripts/build-niche-inputs.mjs \
  "nome do nicho" dados/benchmarks/nichos --country BR --days 90
```

Padroes da primeira versao:

- Anuncios: pelo menos 3 copias/variantes do mesmo criativo, ativos ha pelo menos 15 dias e com CTA `Visitar perfil` (incluindo a variante da fonte `Visit Instagram profile`).
- Reels: publicados nos ultimos 90 dias, minimo de 300.000 views e comentarios/compartilhamentos acima da mediana do proprio perfil quando essas metricas existirem.
- Conteudo editorial: manter apenas materiais ligados a promessa de mentoria, formacao, tecnica, carreira, gestao, captacao, conversao, comunidade ou operacao de clinica; excluir lifestyle e vida pessoal sem ponte clara com a oferta.
- “Copias” e tempo ativo sao sinais de persistencia/iteracao, nao prova de investimento, lucro ou conversao.

## Fluxo Padrao

1. Ler `references/source-capabilities.md` para confirmar capacidades, custos e bloqueios.
2. Ler `references/workflow.md` para executar a coleta de ponta a ponta.
3. Normalizar a entrada:

```bash
node .agents/skills/benchmark-mercado/scripts/build-inputs.mjs lista.txt dados/benchmarks/mercado --limit 1 --max-content 25 --max-ads 25
```

4. Rodar primeiro um piloto controlado: 1 perfil, ate 25 conteudos e ate 25 anuncios por fonte.
5. Usar `.agents/skills/apify-scraping/scripts/run-actor.mjs` para executar atores Apify e copiar imediatamente os datasets para o workspace.
6. Ranquear conteudos organicos:

```bash
node .agents/skills/benchmark-mercado/scripts/select-top-content.mjs dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/instagram-content.json dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/top-content.json --limit 10
```

7. Montar o dossie:

```bash
node .agents/skills/benchmark-mercado/scripts/build-dossier.mjs dados/benchmarks/mercado/YYYY-MM-DD-handle --handle handle
```

8. Aplicar os filtros de criativos:

```bash
node .agents/skills/benchmark-mercado/scripts/select-benchmark-assets.mjs \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/meta-ads.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/instagram-content.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/selected-assets.json
```

9. Revisar o MD final e complementar a analise comercial em portugues: posicionamento, promessa, mecanismo, prova, oferta, CTA, narrativa e oportunidades para a Hurtz.

10. Para transformar o dossie em Wow Document, rodar:

```bash
node .agents/skills/benchmark-mercado/scripts/build-wow-document.mjs \
  dados/benchmarks/mercado/YYYY-MM-DD-slug \
  --niche "nome do nicho"
```

11. Baixar midia publica selecionada, quando houver URL retornada:

```bash
node .agents/skills/benchmark-mercado/scripts/download-public-media.mjs \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/selected-assets.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/Anuncios/videos --kind ads
```

## Saida

Salvar pesquisas por nicho em:

```text
dados/benchmarks/nichos/{YYYY-MM-DD}-{slug}/
├── manifest.json
├── wow-document.md
├── pesquisa/
├── Anuncios/
│   ├── videos/
│   ├── imagens/
│   └── transcricoes/
├── Conteudos em Reels/
│   ├── videos/
│   └── transcricoes/
└── raw/
```

Para pesquisa por perfil, manter o formato legado:

```text
dados/benchmarks/mercado/{YYYY-MM-DD}-{slug}/
├── dossie.md
├── manifest.json
├── raw/
│   ├── instagram-profile.json
│   ├── instagram-content.json
│   ├── top-content.json
│   ├── meta-ads.json
│   └── pages/
└── media/
```

Se algum arquivo nao existir, o dossie deve dizer que aquela fonte ficou indisponivel ou nao foi coletada.

## Documentos finais obrigatorios

Antes de encerrar, gerar e revisar:

1. `manifest.json`: escopo, data, perfis, fontes, limites, thresholds, status e custos.
2. `dossie.md` por perfil: posicionamento, ICP aparente, promessa, oferta, criativos, anuncios, fontes e limitacoes.
3. `wow-document.md`: sintese do nicho, padroes, oportunidades e cinco niveis de consciencia.
4. `transcricoes__consolidado.md`: apenas transcricoes realmente obtidas, com origem e status.
5. `fontes-e-lacunas.md`: URLs consultadas, o que abriu, o que falhou e o que nao pode ser afirmado.

O Wow Document precisa separar explicitamente `Evidencia coletada`, `Inferencia estrategica` e `Hipotese a validar`. Para cada nivel de consciencia, incluir: sinais, dor/desejo, promessa, mecanismo, prova, objecoes, formato, CTA, exemplos e links de referencia.

## Recursos

- `scripts/build-inputs.mjs`: normaliza arrobas/URLs e cria manifestos e inputs iniciais de coleta.
- `scripts/select-top-content.mjs`: ranqueia posts/reels por visualizacoes, plays, likes, comentarios e data.
- `scripts/build-dossier.mjs`: junta dados brutos, paginas e transcricoes em um MD auditavel.
- `scripts/select-benchmark-assets.mjs`: aplica filtros de 90 dias/300k views, engajamento relativo, CTA, copias e persistencia.
- `scripts/build-wow-document.mjs`: gera o documento por niveis de consciencia a partir dos dados coletados e selecionados.
- `scripts/build-market-wow-document.mjs`: consolida varios perfis em um Wow Document unico por nicho.
- `scripts/build-niche-inputs.mjs`: cria manifesto, consultas e pastas de uma pesquisa iniciada por nicho.
- `scripts/download-public-media.mjs`: baixa URLs publicas sem cookies ou headers de autenticacao e grava metadata de auditoria.
- `references/workflow.md`: pipeline completo, comandos e criterios de bloqueio.
- `references/niche-workflow.md`: pesquisa por nicho, buscas paralelas, estrutura de pastas e politica de midia.
- `references/awareness-framework.md`: fonte e definicoes dos cinco niveis de consciencia.
- `references/output-template.md`: estrutura esperada do dossie.
- `references/source-capabilities.md`: fontes, limites, credenciais e fallback.
- `references/multi-agent-workflow.md`: papeis, contratos de saida, paralelizacao e integracao dos agentes.

## Regras Criticas

- Nao raspar conteudo privado, nao burlar login e nao contornar controles de acesso.
- Nao baixar material que so esteja disponivel apos burlar captcha, paywall, controle anti-bot ou permissao privada. Sessao autenticada nao transforma conteudo privado em publico.
- Nao prometer que a pessoa nao anuncia quando a Meta Ads Library nao encontra resultados; registrar "nao encontrado nas buscas testadas".
- Nao inventar transcricao. Se o ator nao trouxer transcript e a midia nao puder ser baixada/transcrita, marcar como lacuna.
- Nao imprimir tokens. Usar `.env` ou variaveis de ambiente.
- Antes de escalar, verificar custo. Acima de USD 5, avisar; acima de USD 20, pedir confirmacao explicita.
- Em conta Apify Free, copiar os datasets para o workspace imediatamente porque a retencao e limitada.
