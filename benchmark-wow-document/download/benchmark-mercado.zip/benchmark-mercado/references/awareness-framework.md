# Niveis de consciencia

O documento usa os cinco niveis associados a Eugene Schwartz em *Breakthrough Advertising*. A fonte de referencia disponibilizada pelo CXL apresenta a sequencia `Most Aware`, `Product Aware`, `Solution Aware`, `Problem Aware` e `Unaware`.

## Regra de uso

Classificar uma mensagem pelo que o prospect ja sabe, nao pelo que o analista acha que ele deveria saber. Registrar a evidencia que sustenta a classificacao e marcar qualquer leitura como inferencia.

| Nivel | O que o prospect conhece | Funcao do conteudo |
|---|---|---|
| Unaware | Nao reconhece claramente o problema ou a necessidade | Criar identificacao, contexto e desejo |
| Problem-Aware | Reconhece o problema, mas nao conhece uma solucao adequada | Nomear a dor e mostrar consequencias |
| Solution-Aware | Sabe que existem solucoes, mas nao conhece ou nao prefere esta oferta | Apresentar mecanismo e criterio de escolha |
| Product-Aware | Conhece o produto/oferta, mas ainda nao esta convencido | Diferenciar, provar e remover objecoes |
| Most-Aware | Conhece a oferta e esta proximo de comprar | Tornar oferta, CTA, urgencia e proximo passo claros |

O Wow Document deve conter, para cada nivel: sinais observados, ganchos, promessa, mecanismo, prova, objecoes, CTA, formatos e referencias de anuncios/Reels.

Fonte: https://cxl.com/institute/wp-content/uploads/2016/09/5-Levels-of-Awareness.pdf
