# Workflow multiagente

## Contrato do agente

Cada agente recebe: nicho, ICP conhecido, lista de perfis/URLs, periodo, thresholds, fontes autorizadas, diretorio de saida e limite de custo.

Cada agente devolve:

```text
status: concluido | parcial | bloqueado
arquivos:
- caminho absoluto
fontes_abertas:
- URL
contagens:
- perfis: 0
- itens: 0
- elegiveis: 0
lacunas:
- motivo
custos_estimados: USD 0.00
observacoes:
- fatos e inferencias separados
```

## Divisao recomendada

| Agente | Escopo | Escreve em |
|---|---|---|
| Descoberta | Google, hashtags, candidatos e links | `pesquisa/descoberta/` |
| Instagram | Perfis e Reels dos ultimos 90 dias | `raw/instagram/` |
| Meta Ads | Biblioteca, CTA, copias e datas | `raw/meta-ads/` |
| Oferta/ICP | Bio, sites, paginas e promessas | `raw/pages/` e `pesquisa/oferta/` |
| QA/editorial | filtros, dedupe, transcricao e lacunas | `pesquisa/qa/` |

O agente de QA pode iniciar depois que as coletas terminarem. O agente principal nao deve delegar a decisao final dos filtros nem a redacao final sem revisar os dados.

## Paralelizacao segura

- Executar agentes independentes em paralelo.
- Separar diretorios de escrita para evitar conflitos.
- Copiar datasets retornados imediatamente para `raw/`.
- Nunca enviar segredo, token ou dado privado ao agente.
- Se dois agentes coletarem o mesmo item, manter a fonte mais completa e registrar a duplicata no QA.
- Reunir resultados somente depois que cada agente retornar status, arquivos e lacunas.

## Portoes de parada

Parar antes de escalar se uma credencial essencial faltar, se o custo projetado ultrapassar USD 5 sem aviso, USD 20 sem confirmacao, ou se a fonte exigir burlar login, captcha, paywall ou controle privado.
