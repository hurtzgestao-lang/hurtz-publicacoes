# Workflow de pesquisa por nicho

## Descoberta

Executar buscas em paralelo:

- Google: nicho, problemas, termos comerciais, cidades, marcas e variantes de linguagem.
- Instagram: hashtags do nicho, hashtags de dor, hashtags de resultado e hashtags locais.
- Perfis encontrados: bio, nome, dominio, CTA, numero de seguidores e sinais de oferta.

Consolidar duplicatas por handle, URL, nome normalizado e dominio. Nao tratar ranking de busca como prova de relevancia; ele serve para gerar candidatos.

## Anuncios

Pesquisar a Meta Ads Library por handle, nome, marca, pagina e dominio. Registrar todas as consultas e o timestamp. Agrupar variacoes do mesmo criativo por URL/ID, hash quando a midia estiver disponivel e similaridade de texto.

Selecionar o conjunto principal apenas quando houver pelo menos 3 variacoes e 15 dias entre o inicio do anuncio e a data de coleta. O CTA exato `Visitar perfil` e filtro principal; outros CTAs ficam em uma secao secundaria.

## Reels

Coletar os Reels dentro da janela de 90 dias. O filtro principal e `views >= 300000`. Para “alto indice”, calcular:

```text
comentarios_por_view = comentarios / views
compartilhamentos_por_view = compartilhamentos / views
```

Priorizar itens acima da mediana do proprio perfil. Se compartilhamentos nao existirem, registrar a ausencia e usar comentarios por view como proxy. Nunca preencher metricas ausentes com zero sem marcar a lacuna.

## Midia e auditoria

Salvar videos em `Anuncios/videos/` ou `Conteudos em Reels/videos/`, imagens nas pastas correspondentes e transcricoes em `transcricoes/`. Cada item precisa conservar URL-fonte, id, data de coleta, data de publicacao/inicio, metricas, filtro aplicado e status de download/transcricao.

Baixar apenas o que estiver publicamente acessivel ou visivel na sessao autorizada. Nao contornar bloqueios, captchas, paywalls ou controles de acesso.
