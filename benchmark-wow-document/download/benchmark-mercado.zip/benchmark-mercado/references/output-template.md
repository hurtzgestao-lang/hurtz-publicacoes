# Template do Dossie

Use esta estrutura para `dossie.md`. Manter URLs-fonte sempre que existirem.

```markdown
# Benchmark - {nome ou arroba}

## Resumo executivo

- Posicionamento:
- Publico-alvo aparente:
- Promessa central:
- Mecanismo de venda:
- Principal prova/autoridade:
- Observacao critica:

## Fontes e status da coleta

| Fonte | Status | Evidencia |
|---|---|---|
| Instagram perfil | coletado/parcial/falhou | URL ou arquivo |
| Instagram conteudo | coletado/parcial/falhou | qtd itens |
| Link da bio/site | coletado/parcial/falhou | URL |
| Meta Ads Library | coletado/parcial/nao encontrado/falhou | buscas testadas |
| Transcricoes | coletado/parcial/falhou | qtd |

## Perfil e posicionamento

- Arroba:
- Nome:
- Bio:
- Seguidores:
- Link da bio:
- Categorias/temas:
- Sinais de autoridade:

## Conteudos organicos fortes

| Rank | URL | Data | Formato | Views/plays | Likes | Comentarios | Gancho | Promessa |
|---|---|---|---|---:|---:|---:|---|---|

### Transcricoes e padroes

Registrar trechos transcritos apenas quando existirem. Separar transcricao literal de interpretacao.

## Site, link da bio e paginas

- URL principal:
- Headline:
- Oferta:
- Promessas:
- Provas:
- CTAs:
- Preco/garantia:
- Friccoes:

## Anuncios Meta

| Rank | Biblioteca/ID | Pagina | Desde | Plataformas | CTA | Destino | Promessa |
|---|---|---|---|---|---|---|---|

## Promessas e mecanismos

- Promessa explicita:
- Promessa implicita:
- Mecanismo unico:
- Inimigo/objecao explorada:
- Transformacao vendida:
- Provas usadas:

## Oportunidades para a Hurtz

- Angulos aproveitaveis:
- Lacunas do mercado:
- Riscos de copiar:
- Como adaptar para a realidade da Hurtz:

## Limitacoes da coleta

Listar tudo que nao abriu, nao foi encontrado, veio incompleto, exigiu login/captcha, excedeu limite ou precisaria de acesso adicional.
```
