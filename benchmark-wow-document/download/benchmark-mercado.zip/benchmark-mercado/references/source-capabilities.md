# Capacidades e Limites das Fontes

## Ambiente atual esperado

- `APIFY_TOKEN`: necessario para atores Apify. Verificar sem imprimir segredo.
- `OPENROUTER_API_KEY`: opcional para sintese editorial depois que os dados brutos estiverem salvos.
- `ffmpeg` e `yt-dlp`: opcionais para baixar e preparar midia publica quando houver URL direta.
- `META_ACCESS_TOKEN`: nao exigido no v1.
- Playwright local: nao exigido no v1; usar Apify Playwright Scraper para paginas JS quando necessario.

## Instagram

Fonte padrao:

- Perfil: `apify/instagram-profile-scraper`.
- Reels/conteudo: `apify/instagram-reel-scraper`, depois `apify/instagram-scraper` se precisar posts alem de reels.

Campos uteis: `username`, `fullName`, `biography`, `externalUrl`, `followersCount`, `postsCount`, `caption`, `url`, `timestamp`, `likesCount`, `commentsCount`, `videoViewCount`, `videoPlayCount`, `viewsCount`, `transcript`, `videoUrl`, `displayUrl`.

Limites:

- Perfis privados ou conteudo que exige sessao podem falhar.
- Views/transcripts podem nao vir em todo ator ou tipo de post.
- Se a coleta vier vazia, tentar ator alternativo e registrar a tentativa.

## Link da bio e sites

Usar scraping HTTP simples quando a pagina abrir. Para paginas renderizadas por JavaScript, usar `apify/playwright-scraper`.

Extrair: titulo, headlines, promessas, CTAs, prova social, preco, garantias, formularios, URLs de destino e paginas intermediarias.

Limites:

- Sites podem bloquear scraping, exigir captcha, login, localizacao ou consentimento.
- Nao tentar burlar paywall/login. Registrar bloqueio e o que precisa ser liberado.

## Meta Ads Library

Padrao v1: ator Apify sem login, com limite pequeno por busca. Buscar por:

- arroba sem `@`;
- nome completo/nome do perfil;
- dominio do site;
- nome da marca/pagina quando aparecer nos dados.

Testar atores atuais antes de escalar, porque schemas e precos mudam. Candidatos:

- `unseenuser/meta-ads`;
- `curious_coder/facebook-ads-library-scraper`;
- outros atores de Meta Ads Library bem avaliados na Apify Store.

Limites:

- Resultado vazio nao prova ausencia de anuncios.
- Alguns atores cobram por resultado ou limitam conta Free.
- Criativos e landing pages so devem ser baixados quando houver URL publica retornada.

## Transcricao

Prioridade:

1. Usar transcript retornado pelo ator Apify.
2. Baixar midia publica quando houver `videoUrl`/`downloadedVideoUrl` e transcrever localmente com `rugido-transcricao-videos`, que usa MLX Whisper quando configurado.
3. Se MLX Whisper nao estiver disponivel, usar `whisper-cli`/whisper.cpp com modelo local como fallback.
4. Registrar lacuna se nao houver midia publica ou transcritor configurado.

Nunca resumir audio como se fosse transcricao literal.
