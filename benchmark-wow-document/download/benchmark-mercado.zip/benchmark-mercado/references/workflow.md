# Workflow de Benchmark de Mercado

## 1. Preparar entrada

Aceitar lista colada, `.txt`, `.md` ou `.csv` com arrobas e URLs.

```bash
node .agents/skills/benchmark-mercado/scripts/build-inputs.mjs lista.txt dados/benchmarks/mercado --limit 1 --max-content 25 --max-ads 25
```

O script cria `manifest.json` geral e uma pasta por perfil com inputs iniciais. Conferir o manifest antes de rodar coletas pagas.

## 2. Verificar Apify

```bash
TOKEN=$(awk -F= '$1=="APIFY_TOKEN"{print $2; exit}' .env)
curl -sS -H "Authorization: Bearer $TOKEN" https://api.apify.com/v2/users/me >/tmp/apify-me.json
unset TOKEN
```

Se falhar, parar e pedir token/credencial. Nao imprimir o token.

## 3. Coletar Instagram

Rodar perfil:

```bash
node .agents/skills/apify-scraping/scripts/run-actor.mjs apify/instagram-profile-scraper \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/inputs/instagram-profile-input.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/instagram-profile \
  --wait-secs 180
```

Copiar ou consolidar `raw/instagram-profile/items.json` para `raw/instagram-profile.json`.

Rodar reels/conteudo:

```bash
node .agents/skills/apify-scraping/scripts/run-actor.mjs apify/instagram-reel-scraper \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/inputs/instagram-reels-input.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/instagram-content \
  --wait-secs 300
```

Copiar ou consolidar `raw/instagram-content/items.json` para `raw/instagram-content.json`.

Se reels vier incompleto, testar `apify/instagram-scraper` com limite baixo.

## 4. Selecionar principais conteudos

```bash
node .agents/skills/benchmark-mercado/scripts/select-top-content.mjs \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/instagram-content.json \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/raw/top-content.json \
  --limit 10
```

Ranquear por views/plays quando existir; caso contrario, usar likes, comentarios e recencia como fallback.

## 5. Coletar site e link da bio

Usar `externalUrl`, `url`, `linkInBio`, ou links encontrados na bio. Salvar paginas em `raw/pages/*.md`.

Para site simples, pode usar `curl`/conversao limpa. Para pagina JS, usar `apify/playwright-scraper` com poucos URLs.

Registrar bloqueios: captcha, login, erro 403/429, paywall, redirecionamento estranho ou pagina vazia.

## 6. Buscar anuncios Meta

Montar buscas por:

- arroba;
- nome do perfil;
- dominio do link da bio;
- nome da marca/pagina.

Comecar com ate 25 resultados por busca. Conferir schema/preco do ator escolhido antes de rodar volume. Salvar em `raw/meta-ads.json`.

Se nao encontrar, registrar as buscas testadas. Nao afirmar que a pessoa nao anuncia.

## 7. Transcrever midias

Usar transcript do ator quando existir. Se nao existir e houver URL publica de video, baixar para `media/` e transcrever localmente, sem depender de ElevenLabs:

```bash
/Users/klebsoncosta/.codex/skills/rugido-transcricao-videos/scripts/transcrever-videos \
  dados/benchmarks/mercado/YYYY-MM-DD-handle/media \
  --output-dir dados/benchmarks/mercado/YYYY-MM-DD-handle/media/transcricoes
```

Esse fluxo usa MLX Whisper local quando o venv `~/.codex/tools/rugido-transcricao/.venv` esta configurado. Salvar `.txt`, `.srt`, `.json`, `.md` e `transcricoes__consolidado.md`.

Se nao conseguir transcrever, escrever no dossie: "transcricao indisponivel; motivo: ...".

## 8. Montar dossie

```bash
node .agents/skills/benchmark-mercado/scripts/build-dossier.mjs dados/benchmarks/mercado/YYYY-MM-DD-handle --handle handle
```

Depois, revisar manualmente o MD e completar a analise comercial. Distinguir evidencia coletada de inferencia.

## Criterios de parada

Parar e avisar o usuario quando:

- credencial essencial estiver ausente;
- ator pago ou busca estimada passar de USD 20;
- fonte exigir login/captcha ou permissao;
- dados vierem vazios em duas fontes alternativas;
- houver risco de violar acesso privado ou contorno de bloqueio.
