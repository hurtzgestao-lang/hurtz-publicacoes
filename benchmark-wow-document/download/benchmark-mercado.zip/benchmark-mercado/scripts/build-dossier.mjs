#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

function usage() {
  console.error(`Usage:
  node build-dossier.mjs <person-dir> [--handle handle] [--out dossie.md]
`);
}

function parseArgs(argv) {
  const args = { personDir: '', handle: '', out: 'dossie.md' };
  const positional = [];
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--handle') args.handle = argv[++i];
    else if (arg === '--out') args.out = argv[++i];
    else positional.push(arg);
  }
  if (positional.length !== 1) {
    usage();
    process.exit(1);
  }
  args.personDir = positional[0];
  return args;
}

function readJsonIfExists(filePath) {
  if (!fs.existsSync(filePath)) return null;
  return JSON.parse(fs.readFileSync(filePath, 'utf8'));
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== 'object') return [];
  for (const key of ['items', 'data', 'results', 'posts', 'reels', 'ads']) {
    if (Array.isArray(value[key])) return value[key];
  }
  return [value];
}

function firstExisting(paths) {
  for (const filePath of paths) {
    if (fs.existsSync(filePath)) return filePath;
  }
  return '';
}

function loadData(personDir) {
  const raw = path.join(personDir, 'raw');
  const profilePath = firstExisting([
    path.join(raw, 'instagram-profile.json'),
    path.join(raw, 'instagram-profile', 'items.json'),
    path.join(raw, 'profile', 'items.json'),
  ]);
  const contentPath = firstExisting([
    path.join(raw, 'top-content.json'),
    path.join(raw, 'instagram-content.json'),
    path.join(raw, 'instagram-content', 'items.json'),
    path.join(raw, 'reels', 'items.json'),
  ]);
  const adsPath = firstExisting([
    path.join(raw, 'meta-ads.json'),
    path.join(raw, 'meta-ads', 'items.json'),
    path.join(raw, 'ads', 'items.json'),
  ]);
  const manifestPath = firstExisting([path.join(personDir, 'manifest.json')]);
  return {
    raw,
    manifest: readJsonIfExists(manifestPath),
    profilePath,
    profile: asArray(readJsonIfExists(profilePath))[0] || null,
    contentPath,
    content: asArray(readJsonIfExists(contentPath)),
    adsPath,
    ads: asArray(readJsonIfExists(adsPath)),
    pages: loadPages(path.join(raw, 'pages')),
  };
}

function loadPages(pagesDir) {
  if (!fs.existsSync(pagesDir)) return [];
  return fs.readdirSync(pagesDir)
    .filter((name) => name.endsWith('.md') || name.endsWith('.txt'))
    .sort()
    .map((name) => {
      const filePath = path.join(pagesDir, name);
      return { name, filePath, text: fs.readFileSync(filePath, 'utf8') };
    });
}

function value(item, keys) {
  for (const key of keys) {
    const current = item?.[key];
    if (current !== undefined && current !== null && current !== '') return current;
  }
  return '';
}

function numberValue(item, keys) {
  const raw = value(item, keys);
  if (typeof raw === 'number') return raw;
  if (typeof raw === 'string' && Number.isFinite(Number(raw))) return Number(raw);
  return '';
}

function mdEscape(text) {
  return String(text ?? '').replace(/\r?\n/g, ' ').replace(/\|/g, '\\|').trim();
}

function short(text, max = 180) {
  const clean = mdEscape(text);
  return clean.length > max ? `${clean.slice(0, max - 3)}...` : clean;
}

function profileName(profile, handle) {
  return value(profile, ['fullName', 'name', 'username']) || handle || 'perfil';
}

function sourceStatus(label, status, evidence) {
  return `| ${label} | ${status} | ${mdEscape(evidence)} |`;
}

function contentRows(content) {
  if (!content.length) return '| - | - | - | - | - | - | - | - | - |';
  return content.slice(0, 15).map((item, index) => {
    const metrics = item.metrics || {};
    const views = metrics.views ?? numberValue(item, ['viewsCount', 'videoViewCount', 'videoPlayCount', 'playCount', 'playsCount']);
    const likes = metrics.likes ?? numberValue(item, ['likesCount', 'likes', 'likeCount']);
    const comments = metrics.comments ?? numberValue(item, ['commentsCount', 'comments', 'commentCount']);
    const url = value(item, ['url', 'inputUrl']) || value(item.raw, ['url', 'inputUrl']);
    const caption = value(item, ['caption', 'text', 'description']) || value(item.raw, ['caption', 'text', 'description']);
    return `| ${index + 1} | ${url ? `[fonte](${url})` : '-'} | ${mdEscape(value(item, ['timestamp', 'date']) || value(item.raw, ['timestamp', 'date']))} | ${mdEscape(value(item, ['type']) || value(item.raw, ['type', 'productType']))} | ${views || 0} | ${likes || 0} | ${comments || 0} | ${short(caption, 90)} | ${short(value(item, ['transcript']) || value(item.raw, ['transcript', 'videoTranscript']), 90)} |`;
  }).join('\n');
}

function adRows(ads) {
  if (!ads.length) return '| - | - | - | - | - | - | - | - |';
  return ads.slice(0, 25).map((ad, index) => {
    const snapshot = ad.snapshot || {};
    const id = value(ad, ['adArchiveId', 'ad_archive_id', 'adId', 'id', 'libraryId']);
    const page = value(ad, ['pageName', 'advertiserName', 'page_name', 'brandName']) || value(snapshot, ['page_name', 'pageName']);
    const started = value(ad, ['startDate', 'start_date_string', 'ad_delivery_start_time', 'adDeliveryStartTime', 'startedAt', 'creationTime']);
    const platformValue = ad.publisherPlatform || ad.publisher_platform || ad.platforms;
    const platforms = Array.isArray(platformValue) ? platformValue.join(', ') : String(platformValue || '');
    const cta = value(ad, ['ctaText', 'cta', 'callToAction']) || value(snapshot, ['cta_text', 'ctaText']);
    const destination = value(snapshot, ['link_url', 'linkUrl']) || value(ad, ['linkUrl', 'landingPageUrl', 'destinationUrl', 'url']);
    const bodyObject = snapshot.body && typeof snapshot.body === 'object' ? snapshot.body.text : '';
    const body = bodyObject || value(snapshot, ['body', 'title']) || value(ad, ['body', 'text', 'adText', 'copy', 'title']);
    return `| ${index + 1} | ${mdEscape(id || '-')} | ${mdEscape(page)} | ${mdEscape(started)} | ${mdEscape(platforms)} | ${mdEscape(cta)} | ${destination ? `[destino](${destination})` : '-'} | ${short(body, 120)} |`;
  }).join('\n');
}

function pageSections(pages) {
  if (!pages.length) return '- Nenhuma pagina salva em `raw/pages/`.';
  return pages.map((page) => {
    const preview = page.text.split(/\r?\n/).filter(Boolean).slice(0, 12).join('\n');
    return `### ${page.name}\n\nArquivo: \`${page.filePath}\`\n\n\`\`\`\`text\n${preview.slice(0, 2000)}\n\`\`\`\``;
  }).join('\n\n');
}

function transcriptSection(content) {
  const transcribed = content
    .map((item, index) => ({ index, item, transcript: value(item, ['transcript']) || value(item.raw, ['transcript', 'videoTranscript', 'transcription']) }))
    .filter((entry) => entry.transcript);
  if (!transcribed.length) return '- Nenhuma transcricao literal encontrada nos dados carregados.';
  return transcribed.slice(0, 8).map((entry) => {
    const url = value(entry.item, ['url', 'inputUrl']) || value(entry.item.raw, ['url', 'inputUrl']);
    return `### Conteudo ${entry.index + 1}${url ? ` - ${url}` : ''}\n\n\`\`\`text\n${String(entry.transcript).slice(0, 2500)}\n\`\`\``;
  }).join('\n\n');
}

function buildMarkdown(args, data) {
  const handle = args.handle || data.manifest?.handle || value(data.profile, ['username']) || path.basename(args.personDir).replace(/^\d{4}-\d{2}-\d{2}-/, '');
  const name = profileName(data.profile, handle);
  const profileUrl = data.manifest?.profileUrl || `https://www.instagram.com/${handle}/`;
  const bio = value(data.profile, ['biography', 'bio', 'description']);
  const externalUrl = value(data.profile, ['externalUrl', 'url', 'website', 'linkInBio']);
  const followers = numberValue(data.profile, ['followersCount', 'followers', 'followerCount']);
  const posts = numberValue(data.profile, ['postsCount', 'posts', 'mediaCount']);
  const statusRows = [
    sourceStatus('Instagram perfil', data.profile ? 'coletado' : 'nao coletado/falhou', data.profilePath || 'arquivo nao encontrado'),
    sourceStatus('Instagram conteudo', data.content.length ? 'coletado/parcial' : 'nao coletado/falhou', data.contentPath ? `${data.content.length} itens em ${data.contentPath}` : 'arquivo nao encontrado'),
    sourceStatus('Link da bio/site', data.pages.length ? 'coletado/parcial' : 'nao coletado/falhou', data.pages.length ? `${data.pages.length} pagina(s)` : externalUrl || 'sem pagina salva'),
    sourceStatus('Meta Ads Library', data.ads.length ? 'coletado/parcial' : 'nao encontrado ou nao coletado', data.adsPath ? `${data.ads.length} itens em ${data.adsPath}` : 'arquivo nao encontrado'),
    sourceStatus('Transcricoes', data.content.some((item) => value(item, ['transcript']) || value(item.raw, ['transcript', 'videoTranscript'])) ? 'parcial/coletado' : 'nao encontrado', 'ver secao de transcricoes'),
  ].join('\n');

  return `# Benchmark - ${name}

## Resumo executivo

- Posicionamento: preencher a partir da bio, conteudos, site e anuncios.
- Publico-alvo aparente: preencher apos leitura.
- Promessa central: preencher com evidencia.
- Mecanismo de venda: preencher com evidencia.
- Principal prova/autoridade: preencher com evidencia.
- Observacao critica: distinguir fato coletado de inferencia.

## Fontes e status da coleta

| Fonte | Status | Evidencia |
|---|---|---|
${statusRows}

## Perfil e posicionamento

- Arroba: [@${handle}](${profileUrl})
- Nome: ${mdEscape(name)}
- Bio: ${mdEscape(bio) || '-'}
- Seguidores: ${followers || '-'}
- Posts: ${posts || '-'}
- Link da bio: ${externalUrl ? `[${externalUrl}](${externalUrl})` : '-'}
- Categorias/temas: preencher apos leitura.
- Sinais de autoridade: preencher apos leitura.

## Conteudos organicos fortes

| Rank | URL | Data | Formato | Views/plays | Likes | Comentarios | Gancho/caption | Transcricao |
|---|---|---|---|---:|---:|---:|---|---|
${contentRows(data.content)}

### Transcricoes e padroes

${transcriptSection(data.content)}

## Site, link da bio e paginas

${pageSections(data.pages)}

## Anuncios Meta

| Rank | Biblioteca/ID | Pagina | Desde | Plataformas | CTA | Destino | Promessa/copy |
|---|---|---|---|---|---|---|---|
${adRows(data.ads)}

## Promessas e mecanismos

- Promessa explicita: preencher com citacao curta ou referencia de fonte.
- Promessa implicita: preencher como inferencia marcada.
- Mecanismo unico: preencher.
- Inimigo/objecao explorada: preencher.
- Transformacao vendida: preencher.
- Provas usadas: preencher.

## Oportunidades para a Hurtz

- Angulos aproveitaveis:
- Lacunas do mercado:
- Riscos de copiar:
- Como adaptar para a realidade da Hurtz:

## Limitacoes da coleta

- Este dossie foi montado a partir dos arquivos encontrados em \`${args.personDir}\`.
- Se uma fonte aparece como nao coletada/falhou, nao concluir ausencia de atividade; repetir com fonte alternativa ou liberar acesso.
- Resultado vazio na Meta Ads Library significa apenas "nao encontrado nas buscas testadas".
- Transcricoes ausentes nao devem ser substituidas por resumo inventado.
`;
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  if (!fs.existsSync(args.personDir) || !fs.statSync(args.personDir).isDirectory()) {
    console.error(`Person directory not found: ${args.personDir}`);
    process.exit(1);
  }
  const data = loadData(args.personDir);
  const markdown = buildMarkdown(args, data);
  const outPath = path.isAbsolute(args.out) ? args.out : path.join(args.personDir, args.out);
  fs.writeFileSync(outPath, markdown);
  console.log(JSON.stringify({ output: path.resolve(outPath), profileLoaded: Boolean(data.profile), contentItems: data.content.length, adsItems: data.ads.length, pages: data.pages.length }, null, 2));
}

main();
