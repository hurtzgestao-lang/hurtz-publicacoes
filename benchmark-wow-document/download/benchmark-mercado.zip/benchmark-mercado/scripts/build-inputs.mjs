#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

function usage() {
  console.error(`Usage:
  node build-inputs.mjs <handles-or-file> [output-root] [--limit N] [--date YYYY-MM-DD] [--max-content 25] [--max-ads 25]

Examples:
  node build-inputs.mjs "@perfil1 @perfil2" dados/benchmarks/mercado --limit 1
  node build-inputs.mjs lista.txt dados/benchmarks/mercado --max-content 25 --max-ads 25
`);
}

function parseArgs(argv) {
  const args = {
    source: '',
    outputRoot: 'dados/benchmarks/mercado',
    limit: Infinity,
    date: new Date().toISOString().slice(0, 10),
    maxContent: 25,
    maxAds: 25,
  };
  const positional = [];
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--limit') args.limit = Number(argv[++i]);
    else if (arg === '--date') args.date = argv[++i];
    else if (arg === '--max-content') args.maxContent = Number(argv[++i]);
    else if (arg === '--max-ads') args.maxAds = Number(argv[++i]);
    else positional.push(arg);
  }
  if (positional.length < 1 || positional.length > 2) {
    usage();
    process.exit(1);
  }
  args.source = positional[0];
  if (positional[1]) args.outputRoot = positional[1];
  for (const key of ['limit', 'maxContent', 'maxAds']) {
    if (!Number.isFinite(args[key]) || args[key] <= 0) {
      console.error(`Invalid ${key}: ${args[key]}`);
      process.exit(1);
    }
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(args.date)) {
    console.error(`Invalid --date: ${args.date}`);
    process.exit(1);
  }
  args.limit = Math.floor(args.limit);
  args.maxContent = Math.floor(args.maxContent);
  args.maxAds = Math.floor(args.maxAds);
  return args;
}

function readSource(source) {
  if (fs.existsSync(source) && fs.statSync(source).isFile()) {
    return fs.readFileSync(source, 'utf8');
  }
  return source;
}

function cleanHandle(value) {
  let handle = value.trim();
  handle = handle.replace(/^https?:\/\/(www\.)?instagram\.com\//i, '');
  handle = handle.replace(/^instagram\.com\//i, '');
  handle = handle.replace(/^@/, '');
  handle = handle.split(/[/?#\s,;]/)[0] || '';
  handle = handle.replace(/[^A-Za-z0-9._]/g, '');
  return handle.toLowerCase();
}

function extractHandles(text) {
  const candidates = new Set();
  const patterns = [
    /@([A-Za-z0-9._]{2,30})/g,
    /(?:https?:\/\/)?(?:www\.)?instagram\.com\/([A-Za-z0-9._]{2,30})(?:[/?#\s]|$)/gi,
  ];
  for (const pattern of patterns) {
    for (const match of text.matchAll(pattern)) {
      candidates.add(cleanHandle(match[1]));
    }
  }
  for (const token of text.split(/[\r\n,;\t ]+/)) {
    if (/^https?:/i.test(token)) continue;
    const handle = cleanHandle(token);
    if (handle && !handle.includes('.') && handle.length >= 2) candidates.add(handle);
  }
  return [...candidates].filter(Boolean);
}

function slugify(handle) {
  return handle.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '') || 'perfil';
}

function writeJson(filePath, data) {
  fs.mkdirSync(path.dirname(filePath), { recursive: true });
  fs.writeFileSync(filePath, `${JSON.stringify(data, null, 2)}\n`);
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const text = readSource(args.source);
  const handles = extractHandles(text).slice(0, args.limit);
  if (!handles.length) {
    console.error('No Instagram handles found.');
    process.exit(1);
  }

  fs.mkdirSync(args.outputRoot, { recursive: true });
  const people = handles.map((handle) => {
    const slug = slugify(handle);
    const personDir = path.join(args.outputRoot, `${args.date}-${slug}`);
    const inputsDir = path.join(personDir, 'inputs');
    const rawDir = path.join(personDir, 'raw');
    const mediaDir = path.join(personDir, 'media');
    fs.mkdirSync(inputsDir, { recursive: true });
    fs.mkdirSync(path.join(rawDir, 'pages'), { recursive: true });
    fs.mkdirSync(mediaDir, { recursive: true });

    const profileInput = { usernames: [handle], userNames: [handle], username: [handle] };
    const reelsInput = {
      usernames: [handle],
      userNames: [handle],
      username: [handle],
      resultsLimit: args.maxContent,
      maxItems: args.maxContent,
      addParentData: false,
      skipPinnedPosts: false,
    };
    const instagramScraperInput = {
      directUrls: [`https://www.instagram.com/${handle}/`],
      resultsType: 'posts',
      resultsLimit: args.maxContent,
      searchLimit: 1,
      addParentData: false,
    };
    const metaAdsSearches = {
      handle,
      maxAdsPerSearch: args.maxAds,
      queries: [handle, `@${handle}`],
      notes: [
        'Inspect the chosen Meta Ads Library actor schema before running.',
        'Add profile full name, brand name, and website domain after profile/site collection.',
      ],
      candidateInputs: {
        genericKeywordSearch: {
          queries: [handle, `@${handle}`],
          searchTerms: [handle],
          resultsLimit: args.maxAds,
          maxItems: args.maxAds,
          country: 'BR',
        },
      },
    };

    writeJson(path.join(inputsDir, 'instagram-profile-input.json'), profileInput);
    writeJson(path.join(inputsDir, 'instagram-reels-input.json'), reelsInput);
    writeJson(path.join(inputsDir, 'instagram-scraper-input.json'), instagramScraperInput);
    writeJson(path.join(inputsDir, 'meta-ads-searches.json'), metaAdsSearches);
    writeJson(path.join(inputsDir, 'meta-ads-input.json'), metaAdsSearches.candidateInputs.genericKeywordSearch);

    const person = {
      handle,
      slug,
      profileUrl: `https://www.instagram.com/${handle}/`,
      personDir,
      inputsDir,
      rawDir,
      mediaDir,
      limits: {
        maxContent: args.maxContent,
        maxAds: args.maxAds,
      },
      files: {
        profileInput: path.join(inputsDir, 'instagram-profile-input.json'),
        reelsInput: path.join(inputsDir, 'instagram-reels-input.json'),
        instagramScraperInput: path.join(inputsDir, 'instagram-scraper-input.json'),
        metaAdsSearches: path.join(inputsDir, 'meta-ads-searches.json'),
        metaAdsInput: path.join(inputsDir, 'meta-ads-input.json'),
      },
    };
    writeJson(path.join(personDir, 'manifest.json'), person);
    return person;
  });

  const manifest = {
    createdAt: new Date().toISOString(),
    outputRoot: args.outputRoot,
    pilotMode: true,
    limits: {
      profiles: handles.length,
      maxContent: args.maxContent,
      maxAds: args.maxAds,
    },
    people,
  };
  const manifestPath = path.join(args.outputRoot, `${args.date}-manifest.json`);
  writeJson(manifestPath, manifest);
  console.log(JSON.stringify({ manifestPath: path.resolve(manifestPath), people }, null, 2));
}

main();
