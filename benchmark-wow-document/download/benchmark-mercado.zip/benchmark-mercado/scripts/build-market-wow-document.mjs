#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

function usage() {
  console.error('Usage: node build-market-wow-document.mjs <manifest.json> <output.md> [--niche "name"]');
  process.exit(1);
}
const positional = [];
let niche = 'Harmonizacao facial';
for (let i = 2; i < process.argv.length; i += 1) {
  if (process.argv[i] === '--niche') niche = process.argv[++i];
  else positional.push(process.argv[i]);
}
if (positional.length !== 2) usage();
const manifest = JSON.parse(fs.readFileSync(positional[0], 'utf8'));
const root = path.dirname(positional[0]);
const people = manifest.people || [];
function json(file, fallback) { return fs.existsSync(file) ? JSON.parse(fs.readFileSync(file, 'utf8')) : fallback; }
function num(item, keys) { for (const key of keys) if (Number.isFinite(Number(item?.[key]))) return Number(item[key]); return null; }
function url(item) { return item?.url || item?.inputUrl || ''; }
function safe(value) { return String(value ?? '').replace(/\|/g, '\\|').replace(/\r?\n/g, ' ').trim(); }
const mentorTerms = ['mentoria', 'mentor', 'curso', 'aula', 'formacao', 'treinamento', 'tecnica', 'anatomia', 'intercorrencia', 'full face', 'profissional', 'injetora', 'injetor', 'carreira', 'metodo', 'planejamento', 'captacao', 'conversao', 'faturamento', 'precificacao', 'marketing', 'autoridade', 'comunidade', 'turma', 'workshop', 'seguranca', 'class10', 'aluna', 'aluno', 'raciocinio clinico', 'jornada'];
const personalTerms = ['familia', 'mae', 'pai', 'filho', 'namorado', 'namorada', 'casamento', 'aniversario', 'ferias', 'viagem', 'look', 'rotina', 'danca', 'musica', 'fe', 'deus', 'lifestyle', 'amigos', 'amor', 'cabelo', 'presente'];
function isMentorshipContent(item) {
  const text = String([item.caption, item.alt, item.firstComment, item.description].filter(Boolean).join(' ')).toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
  const mentorScore = mentorTerms.filter((term) => text.includes(term)).length;
  const personalScore = personalTerms.filter((term) => text.includes(term)).length;
  return mentorScore > 0 && personalScore === 0;
}
const records = people.map((person) => {
  const dir = path.resolve(root, path.basename(person.personDir));
  const profile = json(path.join(dir, 'raw/instagram-profile.json'), [])[0] || {};
  const content = json(path.join(dir, 'raw/instagram-content.json'), []);
  const ads = json(path.join(dir, 'raw/meta-ads.json'), []);
  const selected = json(path.join(dir, 'raw/selected-assets.json'), { ads: [], reels: [] });
  return { person, dir, profile, content, mentorContent: content.filter(isMentorshipContent), ads, selected };
});
const topReels = records.flatMap((record) => record.mentorContent.map((item) => ({ record, item, views: num(item, ['viewsCount', 'videoViewCount', 'videoPlayCount', 'playCount', 'views', 'viewCount']) || 0, comments: num(item, ['commentsCount', 'comments', 'commentCount']) || 0, likes: num(item, ['likesCount', 'likes', 'likeCount']) || 0 }))).sort((a, b) => b.views - a.views).slice(0, 30);
const topAds = records.flatMap((record) => record.ads.map((item) => ({ record, item, copies: num(item, ['collation_count', 'collationCount']) || 1, start: item.start_date_string || item.start_date || '', cta: item.snapshot?.cta_text || '', active: item.is_active === true }))).sort((a, b) => b.copies - a.copies);
const selectedReels = records.reduce((sum, record) => sum + record.selected.reels.length, 0);
const selectedAds = records.reduce((sum, record) => sum + record.selected.ads.length, 0);
const playerRows = records.map((record) => `| [@${safe(record.person.handle)}](${record.person.profileUrl}) | ${safe(record.profile.fullName || record.person.handle)} | ${num(record.profile, ['followersCount', 'followers']) ?? '-'} | ${record.mentorContent.length} | ${record.ads.length} | ${record.selected.reels.length} | ${record.selected.ads.length} |`).join('\n');
const reelRows = topReels.map((entry, index) => `| ${index + 1} | @${safe(entry.record.person.handle)} | ${url(entry.item) ? `[fonte](${url(entry.item)})` : '-'} | ${entry.views.toLocaleString('pt-BR')} | ${entry.likes.toLocaleString('pt-BR')} | ${entry.comments.toLocaleString('pt-BR')} | ${safe(entry.item.caption).slice(0, 160)} |`).join('\n');
const adRows = topAds.slice(0, 40).map((entry, index) => `| ${index + 1} | @${safe(entry.record.person.handle)} | ${entry.item.ad_archive_id || '-'} | ${entry.copies} | ${safe(entry.start)} | ${safe(entry.cta) || '-'} | ${entry.active ? 'ativo' : 'nao confirmado'} | ${entry.item.url ? `[biblioteca](${entry.item.url})` : '-'} |`).join('\n');
const markdown = `# Wow Document — ${niche}

> Coleta realizada em ${new Date().toISOString()}. Este documento diferencia evidencia coletada, ausencia de evidencia e inferencia estrategica.

## Resumo executivo

- Players analisados: ${records.length}
- Itens de Reels coletados com foco em mentoria: ${records.reduce((sum, record) => sum + record.mentorContent.length, 0)}
- Anuncios coletados: ${records.reduce((sum, record) => sum + record.ads.length, 0)}
- Reels que passaram nos filtros: ${selectedReels}
- Anuncios que passaram nos filtros estritos: ${selectedAds}
- Foco editorial: somente promessa de mentoria, formacao, tecnica, carreira, gestao, captacao, conversao, comunidade e operacao de clinica. Lifestyle e vida pessoal foram excluidos.
- Filtros: Reels nos ultimos 90 dias, 300k+ views e engajamento relativo; anuncios com 3+ copias, 15+ dias e CTA “Visitar perfil”.

## Players

| Perfil | Nome | Seguidores | Reels de mentoria | Anuncios coletados | Reels elegiveis | Anuncios elegiveis |
|---|---|---:|---:|---:|---:|---:|
${playerRows}

## Reels de maior alcance observados

| Rank | Perfil | Fonte | Views | Likes | Comentarios | Caption/gancho |
|---:|---|---|---:|---:|---:|---|
${reelRows || '| - | - | - | - | - | - | Nenhum item |'}

Os itens acima sao ranking de alcance observado apenas entre conteudos relacionados a mentoria. Conteudos pessoais, familiares, lifestyle e entretenimento sem ponte com a oferta foram excluidos.

## Anuncios ativos observados

| Rank | Perfil pesquisado | ID | Copias/colacao | Inicio | CTA | Status | Biblioteca |
|---:|---|---|---:|---|---|---|---|
${adRows || '| - | - | - | - | - | - | - | Nenhum item |'}

“Copias/colacao” e o agrupamento retornado pela fonte; nao e prova de investimento ou conversao. Nenhum item deve ser chamado de escalado sem cumprir todos os filtros.

## ICP aparente

- Publico principal: profissionais da saude e estetica que atuam ou desejam atuar com Harmonizacao Orofacial.
- Momento de compra: busca por seguranca tecnica, atualizacao, autoridade, previsibilidade de atendimento e aumento de faturamento.
- Dores recorrentes a validar: inseguranca na aplicacao, medo de intercorrencias, dificuldade de planejamento Full Face, baixa conversao e estagnacao profissional.
- Desejos: tornar-se referencia, atender com mais seguranca, cobrar mais e construir uma carreira sustentavel.
- Objecoes provaveis: custo, confiabilidade do professor, aplicabilidade pratica, respaldo legal e tempo para estudar.

## Niveis de consciencia

### Unaware

- Sinais: conteudos de identificacao com carreira, inseguranca e desejo de evolucao.
- Conteudo recomendado: sintomas de estagnacao, erros invisiveis e custo de continuar no improviso.
- Gancho/CTA a testar: diagnostico do nivel tecnico e convite para aula introdutoria.

### Problem-Aware

- Sinais: medo de intercorrencias, inseguranca na dose e dificuldade de converter pacientes.
- Conteudo recomendado: demonstrar o problema com casos, protocolos e consequencias praticas.
- Gancho/CTA a testar: checklist de seguranca ou aula de planejamento.

### Solution-Aware

- Sinais: mercado oferece cursos, comunidades, plataformas e metodos Full Face.
- Conteudo recomendado: comparar metodo, pratica, suporte, atualizacao, negocio e respaldo.
- Gancho/CTA a testar: aula demonstrativa ou comparativo de metodos.

### Product-Aware

- Sinais: nomes de ofertas e professores aparecem em paginas, bios, anuncios e depoimentos.
- Conteudo recomendado: prova de aplicacao, diferenciais, comunidade, resultados e tratamento de objecoes.
- Gancho/CTA a testar: demonstracao, depoimento verificavel e oferta com garantia.

### Most-Aware

- Sinais: paginas com planos, bonus, garantia, vagas e CTA de assinatura/entrada.
- Conteudo recomendado: oferta, prazo, bonus, condicoes, garantia e proximo passo sem ampliar a promessa.
- Gancho/CTA a testar: assinatura, aplicacao ou conversa com especialista.

## Padroes de posicionamento observados

- Tecnica combinada com seguranca e raciocinio clinico.
- Transformacao de inseguranca/improviso em metodo e referencia.
- Promessa profissional: atrair pacientes, fechar procedimentos de maior valor e aumentar faturamento.
- Comunidade e suporte como mecanismo de reducao de solidao e aceleracao.
- Prova baseada em professores, numero de alunos, aulas, depoimentos, pratica e certificacoes alegadas.

## Oportunidades para a Hurtz

- Criar campanhas por nivel de consciencia, sem usar a mesma promessa para todos.
- Explorar a ponte entre tecnica, aquisicao de pacientes e conversao de procedimentos.
- Usar criativos de “erro/risco” para Problem-Aware e demonstracoes de metodo para Solution-Aware.
- Para Product-Aware, comparar mecanismos e provas, nao apenas repetir “curso completo”.
- Validar claims de faturamento, certificacao e escala antes de reproduzir qualquer promessa.

## Fontes comerciais fornecidas

- https://www.souhof.com.br/
- https://alexiaduarte.com/fullfaceclub-org/
- https://alexiaduarte.com/materiais/
- https://www.facialacademy.com.br/cursos/facialclass-google

## Limitacoes

- O ator de Reels retornou no maximo 50 itens por perfil; o ranking nao representa todo o historico.
- O CTA “Visitar perfil” nao apareceu nos itens elegiveis coletados; CTAs diferentes foram mantidos como secundarios.
- Conteudos com metricas ausentes nao foram promovidos por inferencia.
- Paginas que responderam 406 via HTTP foram preservadas como bloqueadas; quando possivel, a leitura foi feita por extracao web publica.
- Nenhuma conclusao de faturamento, investimento ou performance financeira foi inferida apenas de quantidade de copias, views ou tempo ativo.
`;
fs.mkdirSync(path.dirname(positional[1]), { recursive: true });
fs.writeFileSync(positional[1], markdown);
console.log(JSON.stringify({ output: path.resolve(positional[1]), players: records.length, reelsCollected: topReels.length, adsCollected: topAds.length, selectedReels, selectedAds }, null, 2));
