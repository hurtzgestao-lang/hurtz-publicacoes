#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

function usage() {
  console.error('Usage: node build-niche-inputs.mjs "nicho" [output-root] [--country BR] [--days 90]');
  process.exit(1);
}

const positional = [];
const options = { country: 'BR', days: 90 };
for (let i = 2; i < process.argv.length; i += 1) {
  const arg = process.argv[i];
  if (arg === '--country') options.country = process.argv[++i];
  else if (arg === '--days') options.days = Number(process.argv[++i]);
  else positional.push(arg);
}
if (positional.length < 1 || positional.length > 2 || !Number.isFinite(options.days) || options.days <= 0) usage();

const niche = positional[0].trim();
const root = positional[1] || 'dados/benchmarks/nichos';
const date = new Date().toISOString().slice(0, 10);
const slug = niche.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '') || 'nicho';
const dir = path.join(root, `${date}-${slug}`);
const directories = ['pesquisa', 'raw', 'Anuncios/videos', 'Anuncios/imagens', 'Anuncios/transcricoes', 'Conteudos em Reels/videos', 'Conteudos em Reels/imagens', 'Conteudos em Reels/transcricoes'];
for (const relative of directories) fs.mkdirSync(path.join(dir, relative), { recursive: true });

const terms = [niche, `${niche} problemas`, `${niche} solução`, `${niche} resultados`, `${niche} como funciona`];
const hashtags = [...new Set(terms.flatMap((term) => term.toLowerCase().split(/\s+/).filter(Boolean).map((term) => `#${term.replace(/[^a-z0-9áàâãéêíóôõúç]/gi, '')}`)))];
const manifest = {
  createdAt: new Date().toISOString(),
  niche,
  slug,
  country: options.country,
  reelWindowDays: options.days,
  thresholds: { minimumAdCopies: 3, minimumAdDays: 15, minimumReelViews: 300000, engagementBaseline: 'profile median' },
  search: { googleQueries: terms, instagramHashtags: hashtags, metaAdsQueries: [niche] },
  directories,
  status: 'inputs-created',
};
fs.writeFileSync(path.join(dir, 'manifest.json'), `${JSON.stringify(manifest, null, 2)}\n`);
fs.writeFileSync(path.join(dir, 'pesquisa', 'search-queries.json'), `${JSON.stringify(manifest.search, null, 2)}\n`);
console.log(JSON.stringify({ output: path.resolve(dir), manifest: path.resolve(dir, 'manifest.json'), queries: terms.length, hashtags: hashtags.length }, null, 2));
