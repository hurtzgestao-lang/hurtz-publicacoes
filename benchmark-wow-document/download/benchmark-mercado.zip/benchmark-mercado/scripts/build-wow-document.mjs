#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

function usage() { console.error('Usage: node build-wow-document.mjs <benchmark-dir> [--niche "name"] [--out wow-document.md]'); process.exit(1); }
const positional = [];
const options = { niche: '', out: 'wow-document.md' };
for (let i = 2; i < process.argv.length; i += 1) {
  const arg = process.argv[i];
  if (arg === '--niche') options.niche = process.argv[++i];
  else if (arg === '--out') options.out = process.argv[++i];
  else positional.push(arg);
}
if (positional.length !== 1) usage();
const dir = positional[0];
if (!fs.existsSync(dir) || !fs.statSync(dir).isDirectory()) throw new Error(`Benchmark directory not found: ${dir}`);

function readJson(relativePath) {
  const filePath = path.join(dir, relativePath);
  return fs.existsSync(filePath) ? JSON.parse(fs.readFileSync(filePath, 'utf8')) : null;
}
function first(...names) { for (const name of names) { const value = readJson(name); if (value) return value; } return null; }
function sourceUrl(item) { return item?.url || item?.inputUrl || item?.adLibraryUrl || item?.snapshotUrl || ''; }
function rows(items, kind) {
  if (!Array.isArray(items) || !items.length) return '- Nenhum item elegivel encontrado.';
  return items.slice(0, 30).map((entry, index) => {
    const item = entry.item || entry.variants?.[0] || entry;
    const url = sourceUrl(item);
    const source = url ? `[fonte](${url})` : 'URL ausente';
    const metrics = kind === 'reel'
      ? `views: ${entry.views ?? '-'}, comentarios/view: ${entry.commentsPerView == null ? 'indisponivel' : entry.commentsPerView.toFixed(5)}`
      : `copias: ${entry.copyCount}, dias ativos: ${entry.daysActive ?? 'indisponivel'}`;
    return `${index + 1}. ${source} — ${metrics}${item.transcript || item.videoTranscript ? ' — transcript disponivel' : ''}`;
  }).join('\n');
}

const selected = first('raw/selected-assets.json', 'selected-assets.json') || { ads: [], reels: [], thresholds: {} };
const manifest = readJson('manifest.json') || {};
const niche = options.niche || manifest.niche || manifest.handle || path.basename(dir);
const sourceLinks = [...new Set([
  ...selected.ads.flatMap((group) => (group.variants || []).map(sourceUrl)),
  ...selected.reels.map((entry) => sourceUrl(entry.item || entry)),
].filter(Boolean))];
const levels = [
  ['Unaware', 'Nao reconhece claramente o problema ou a necessidade.', 'Criar identificacao, contexto e desejo.'],
  ['Problem-Aware', 'Reconhece o problema, mas nao conhece uma solucao adequada.', 'Nomear a dor e mostrar consequencias.'],
  ['Solution-Aware', 'Sabe que existem solucoes, mas nao conhece ou nao prefere esta oferta.', 'Apresentar mecanismo e criterio de escolha.'],
  ['Product-Aware', 'Conhece a oferta, mas ainda nao esta convencido.', 'Diferenciar, provar e remover objecoes.'],
  ['Most-Aware', 'Conhece a oferta e esta proximo de comprar.', 'Tornar oferta, CTA, urgencia e proximo passo claros.'],
];
const markdown = `# Wow Document — ${niche}

> Documento de inteligencia de mercado gerado em ${new Date().toISOString()}. Fatos coletados, transcricoes e inferencias devem permanecer separados.

## Resumo executivo

- Nicho: ${niche}
- Anuncios elegiveis: ${selected.ads.length}
- Reels elegiveis: ${selected.reels.length}
- Filtros: \`${JSON.stringify(selected.thresholds || {})}\`
- Leitura principal: preencher apos revisar as evidencias abaixo.

## ICP e mercado

- Quem parece comprar:
- Dor urgente:
- Desejo principal:
- Objecoes:
- Linguagem recorrente:
- Provas de autoridade:
- Inferencias a validar:

## Criativos selecionados

### Anuncios persistentes

${rows(selected.ads, 'ad')}

### Reels de alto alcance e engajamento relativo

${rows(selected.reels, 'reel')}

## Niveis de consciencia

${levels.map(([name, definition, role]) => `### ${name}\n\n**Definicao:** ${definition}\n\n**Funcao do conteudo:** ${role}\n\n- Sinais observados:\n- Ganchos:\n- Promessa:\n- Mecanismo:\n- Provas:\n- Objecoes:\n- CTA:\n- Formatos que parecem converter:\n- Referencias: revisar os itens selecionados e inserir links especificos.\n`).join('\n')}
## Padroes de copy e oferta

- Promessas explicitas:
- Promessas implicitas:
- Mecanismos repetidos:
- Inimigos/objecoes:
- Estruturas de gancho:
- CTAs:
- Diferenciais alegados:
- Saturacoes:
- Lacunas:

## Oportunidades para a Hurtz

- Angulos adaptaveis:
- Conteudos por nivel de consciencia:
- Ofertas a testar:
- Provas que faltam no mercado:
- Riscos de copiar:

## Fontes e auditoria

${sourceLinks.length ? sourceLinks.map((url) => `- ${url}`).join('\n') : '- Nenhum link-fonte foi encontrado nos dados selecionados.'}

## Limitacoes

- Copias e dias ativos sao proxies de persistencia, nao evidencia de performance financeira.
- Metricas ausentes nao foram tratadas como prova de baixo engajamento.
- Conteudo bloqueado, privado ou sem URL publica deve ser listado aqui durante a revisao.
- As secoes analiticas em branco exigem revisao humana ou uma etapa de sintese posterior; nao devem ser preenchidas com fatos inventados.
`;
const output = path.isAbsolute(options.out) ? options.out : path.join(dir, options.out);
fs.mkdirSync(path.dirname(output), { recursive: true });
fs.writeFileSync(output, markdown);
console.log(JSON.stringify({ output: path.resolve(output), niche, ads: selected.ads.length, reels: selected.reels.length }, null, 2));
