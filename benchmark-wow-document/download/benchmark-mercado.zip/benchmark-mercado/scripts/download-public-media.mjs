#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

function usage() {
  console.error('Usage: node download-public-media.mjs <items.json> <output-dir> [--kind ads|reels]');
  process.exit(1);
}
const positional = [];
let kind = 'reels';
for (let i = 2; i < process.argv.length; i += 1) {
  if (process.argv[i] === '--kind') kind = process.argv[++i];
  else positional.push(process.argv[i]);
}
if (positional.length !== 2 || !['ads', 'reels'].includes(kind)) usage();
const [inputPath, outputDir] = positional;
const parsed = JSON.parse(fs.readFileSync(inputPath, 'utf8'));
const rawItems = Array.isArray(parsed) ? parsed : (kind === 'ads' ? (parsed.ads || []) : (parsed.reels || parsed.items || parsed.data || []));
const items = kind === 'ads' ? rawItems.flatMap((entry) => entry.variants || [entry]) : rawItems;
const target = path.resolve(outputDir);
fs.mkdirSync(target, { recursive: true });

function urlOf(item) {
  return item.videoUrl || item.downloadedVideoUrl || item.imageUrl || item.displayUrl || item.display_url || item.snapshot?.video_url || item.snapshot?.image_url || item.snapshot?.videos?.[0]?.video_hd_url || item.snapshot?.videos?.[0]?.video_sd_url || item.snapshot?.images?.[0]?.original_image_url || '';
}
function extension(url, contentType = '') {
  const pathname = new URL(url).pathname.toLowerCase();
  const match = pathname.match(/\.(mp4|mov|webm|jpg|jpeg|png|webp)$/);
  if (match) return `.${match[1] === 'jpeg' ? 'jpg' : match[1]}`;
  if (contentType.includes('image')) return '.jpg';
  return '.mp4';
}
function safeName(item, index, ext) {
  const id = item.id || item.shortCode || item.adArchiveId || item.adId || `item-${index + 1}`;
  return `${String(id).replace(/[^a-zA-Z0-9._-]/g, '_')}${ext}`;
}

const metadata = [];
for (let index = 0; index < items.length; index += 1) {
  const item = items[index]?.item || items[index];
  const url = urlOf(item);
  const record = { index, kind, sourceUrl: url, status: 'skipped' };
  if (!/^https?:\/\//i.test(url)) {
    record.reason = 'public media URL not provided';
    metadata.push(record);
    continue;
  }
  try {
    const response = await fetch(url, { redirect: 'follow' });
    if (!response.ok) throw new Error(`HTTP ${response.status}`);
    const contentType = response.headers.get('content-type') || '';
    const filePath = path.join(target, safeName(item, index, extension(url, contentType)));
    fs.writeFileSync(filePath, Buffer.from(await response.arrayBuffer()));
    record.status = 'downloaded';
    record.localPath = path.relative(process.cwd(), filePath);
    record.contentType = contentType;
    record.bytes = fs.statSync(filePath).size;
  } catch (error) {
    record.status = 'failed';
    record.reason = error.message;
  }
  metadata.push(record);
}
const metadataPath = path.join(path.dirname(target), `${path.basename(target)}-metadata.json`);
fs.writeFileSync(metadataPath, `${JSON.stringify({ downloadedAt: new Date().toISOString(), kind, items: metadata }, null, 2)}\n`);
console.log(JSON.stringify({ output: target, metadata: metadataPath, downloaded: metadata.filter((item) => item.status === 'downloaded').length, failed: metadata.filter((item) => item.status === 'failed').length, skipped: metadata.filter((item) => item.status === 'skipped').length }, null, 2));
