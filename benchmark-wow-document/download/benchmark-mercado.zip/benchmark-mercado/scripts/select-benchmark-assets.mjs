#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

function usage() {
  console.error('Usage: node select-benchmark-assets.mjs <ads.json> <reels.json> <output.json> [--days 90] [--min-views 300000] [--min-copies 3] [--min-ad-days 15]');
  process.exit(1);
}

function parseArgs(argv) {
  const positional = [];
  const out = { days: 90, minViews: 300000, minCopies: 3, minAdDays: 15 };
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--days') out.days = Number(argv[++i]);
    else if (arg === '--min-views') out.minViews = Number(argv[++i]);
    else if (arg === '--min-copies') out.minCopies = Number(argv[++i]);
    else if (arg === '--min-ad-days') out.minAdDays = Number(argv[++i]);
    else positional.push(arg);
  }
  if (positional.length !== 3 || Object.values(out).some((value) => !Number.isFinite(value) || value < 0)) usage();
  return { ...out, adsPath: positional[0], reelsPath: positional[1], output: positional[2] };
}

function asList(value) {
  if (Array.isArray(value)) return value;
  if (value && typeof value === 'object') {
    for (const key of ['items', 'data', 'results', 'ads', 'reels', 'posts']) {
      if (Array.isArray(value[key])) return value[key];
    }
    return [value];
  }
  return [];
}

function readItems(filePath) { return asList(JSON.parse(fs.readFileSync(filePath, 'utf8'))); }

function number(item, keys) {
  for (const key of keys) {
    const value = item?.[key];
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value);
  }
  return null;
}

function timestamp(item, keys) {
  for (const key of keys) {
    const parsed = item?.[key] ? Date.parse(item[key]) : NaN;
    if (Number.isFinite(parsed)) return parsed;
  }
  return null;
}

function median(values) {
  const sorted = values.filter(Number.isFinite).sort((a, b) => a - b);
  if (!sorted.length) return null;
  const middle = Math.floor(sorted.length / 2);
  return sorted.length % 2 ? sorted[middle] : (sorted[middle - 1] + sorted[middle]) / 2;
}

function text(item) {
  return String(item?.body || item?.copy || item?.text || item?.caption || item?.title || '').trim();
}

function creativeKey(item) {
  const value = item?.creativeId || item?.creative_id || item?.videoUrl || item?.imageUrl || item?.displayUrl || item?.id;
  return String(value || text(item).toLowerCase().replace(/\s+/g, ' ').slice(0, 120) || JSON.stringify(item).slice(0, 160));
}

function cta(item) {
  return String(item?.ctaText || item?.cta || item?.callToAction || item?.snapshot?.cta_text || '').trim().toLowerCase();
}

function isProfileVisitCta(item) {
  const value = cta(item);
  return value === 'visitar perfil' || value === 'visit profile' || value === 'visit instagram profile' || value.includes('visit instagram profile');
}

function selectAds(items, options, now) {
  const groups = new Map();
  for (const item of items) {
    const key = item?.collation_id || item?.collationId || creativeKey(item);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(item);
  }
  return [...groups.entries()].map(([group, variants]) => {
    const starts = variants.map((item) => timestamp(item, ['startDate', 'start_date', 'start_date_string', 'ad_delivery_start_time', 'adDeliveryStartTime', 'startedAt', 'creationTime'])).filter(Number.isFinite);
    const oldest = starts.length ? Math.min(...starts) : null;
    const daysActive = oldest == null ? null : Math.max(0, (now - oldest) / 86400000);
    const hasProfileCta = variants.some(isProfileVisitCta);
    const reportedCopyCount = Math.max(...variants.map((item) => number(item, ['collation_count', 'collationCount']) ?? 0), 0);
    const copyCount = Math.max(variants.length, reportedCopyCount);
    return {
      group,
      copyCount,
      daysActive: daysActive == null ? null : Number(daysActive.toFixed(1)),
      hasProfileCta,
      qualifies: copyCount >= options.minCopies && daysActive != null && daysActive >= options.minAdDays && hasProfileCta,
      variants,
    };
  }).filter((item) => item.qualifies).sort((a, b) => b.copyCount - a.copyCount || b.daysActive - a.daysActive);
}

function selectReels(items, options, now) {
  const candidates = items.map((item) => {
    const views = number(item, ['viewsCount', 'videoViewCount', 'videoPlayCount', 'playCount', 'playsCount', 'views', 'viewCount']) ?? 0;
    const comments = number(item, ['commentsCount', 'comments', 'commentCount']);
    const shares = number(item, ['sharesCount', 'shares', 'shareCount']);
    const published = timestamp(item, ['timestamp', 'takenAt', 'createdAt', 'date', 'uploadDate']);
    const ageDays = published == null ? null : Math.max(0, (now - published) / 86400000);
    return { item, views, comments, shares, ageDays, commentsPerView: comments == null || !views ? null : comments / views, sharesPerView: shares == null || !views ? null : shares / views };
  }).filter((item) => item.views >= options.minViews && item.ageDays != null && item.ageDays <= options.days);
  const commentMedian = median(candidates.map((item) => item.commentsPerView));
  const shareMedian = median(candidates.map((item) => item.sharesPerView));
  return candidates.map((candidate) => ({
    ...candidate,
    qualifies: (commentMedian == null || candidate.commentsPerView >= commentMedian) && (shareMedian == null || candidate.sharesPerView >= shareMedian),
    engagementBaselines: { commentMedian, shareMedian },
  })).filter((item) => item.qualifies).sort((a, b) => b.views - a.views);
}

const options = parseArgs(process.argv.slice(2));
const adsInput = readItems(options.adsPath);
const reelsInput = readItems(options.reelsPath);
const now = Date.now();
const ads = selectAds(adsInput, options, now);
const reels = selectReels(reelsInput, options, now);
const result = {
  collectedAt: new Date(now).toISOString(),
  thresholds: { adMinCopies: options.minCopies, adMinDays: options.minAdDays, reelDays: options.days, reelMinViews: options.minViews, engagement: 'above median of candidate set' },
  ads,
  reels,
  summary: { inputAds: adsInput.length, qualifyingAdGroups: ads.length, inputReels: reelsInput.length, qualifyingReels: reels.length },
};
fs.mkdirSync(path.dirname(options.output), { recursive: true });
fs.writeFileSync(options.output, `${JSON.stringify(result, null, 2)}\n`);
console.log(JSON.stringify({ output: path.resolve(options.output), ...result.summary }, null, 2));
