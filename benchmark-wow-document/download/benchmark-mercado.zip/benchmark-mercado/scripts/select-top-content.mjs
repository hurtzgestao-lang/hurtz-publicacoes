#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';

function usage() {
  console.error(`Usage:
  node select-top-content.mjs <input-json> <output-json> [--limit 10]
`);
}

function parseArgs(argv) {
  const args = { input: '', output: '', limit: 10 };
  const positional = [];
  for (let i = 0; i < argv.length; i += 1) {
    const arg = argv[i];
    if (arg === '--limit') args.limit = Number(argv[++i]);
    else positional.push(arg);
  }
  if (positional.length !== 2 || !Number.isFinite(args.limit) || args.limit <= 0) {
    usage();
    process.exit(1);
  }
  args.input = positional[0];
  args.output = positional[1];
  args.limit = Math.floor(args.limit);
  return args;
}

function flatten(value) {
  if (Array.isArray(value)) return value;
  if (!value || typeof value !== 'object') return [];
  for (const key of ['items', 'data', 'results', 'posts', 'reels']) {
    if (Array.isArray(value[key])) return value[key];
  }
  return [value];
}

function firstNumber(item, keys) {
  for (const key of keys) {
    const value = item?.[key];
    if (typeof value === 'number' && Number.isFinite(value)) return value;
    if (typeof value === 'string' && value.trim() && Number.isFinite(Number(value))) return Number(value);
  }
  return 0;
}

function timestampMs(item) {
  const value = item.timestamp || item.takenAt || item.createdAt || item.date || item.uploadDate;
  const ms = value ? Date.parse(value) : NaN;
  return Number.isFinite(ms) ? ms : 0;
}

function getUrl(item) {
  return item.url || item.inputUrl || item.shortCode && `https://www.instagram.com/p/${item.shortCode}/` || '';
}

function scoreItem(item) {
  const views = firstNumber(item, ['viewsCount', 'videoViewCount', 'videoPlayCount', 'playCount', 'playsCount', 'videoViews', 'viewCount']);
  const likes = firstNumber(item, ['likesCount', 'likes', 'likeCount']);
  const comments = firstNumber(item, ['commentsCount', 'comments', 'commentCount']);
  const shares = firstNumber(item, ['sharesCount', 'shares', 'shareCount']);
  const recencyDays = timestampMs(item) ? Math.max(0, (Date.now() - timestampMs(item)) / 86400000) : 3650;
  const recencyBoost = Math.max(0, 100 - Math.min(100, recencyDays / 7));
  const score = views * 1 + likes * 8 + comments * 25 + shares * 40 + recencyBoost;
  return { views, likes, comments, shares, recencyDays, score };
}

function simplify(item, rank, metrics) {
  return {
    rank,
    score: Number(metrics.score.toFixed(2)),
    url: getUrl(item),
    type: item.type || item.productType || item.mediaType || '',
    timestamp: item.timestamp || item.takenAt || item.createdAt || item.date || '',
    caption: item.caption || item.text || item.description || '',
    transcript: item.transcript || item.videoTranscript || item.transcription || '',
    metrics: {
      views: metrics.views,
      likes: metrics.likes,
      comments: metrics.comments,
      shares: metrics.shares,
    },
    media: {
      videoUrl: item.videoUrl || item.video_url || item.downloadedVideoUrl || '',
      displayUrl: item.displayUrl || item.imageUrl || item.thumbnailUrl || '',
    },
    raw: item,
  };
}

function main() {
  const args = parseArgs(process.argv.slice(2));
  const parsed = JSON.parse(fs.readFileSync(args.input, 'utf8'));
  const items = flatten(parsed);
  const ranked = items
    .map((item) => ({ item, metrics: scoreItem(item) }))
    .sort((a, b) => b.metrics.score - a.metrics.score || timestampMs(b.item) - timestampMs(a.item))
    .slice(0, args.limit)
    .map(({ item, metrics }, index) => simplify(item, index + 1, metrics));

  fs.mkdirSync(path.dirname(args.output), { recursive: true });
  fs.writeFileSync(args.output, `${JSON.stringify(ranked, null, 2)}\n`);
  console.log(JSON.stringify({ inputItems: items.length, outputItems: ranked.length, output: path.resolve(args.output) }, null, 2));
}

main();
